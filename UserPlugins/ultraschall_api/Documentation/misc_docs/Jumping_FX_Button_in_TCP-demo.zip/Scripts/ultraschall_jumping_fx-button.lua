--[[
################################################################################
# 
# Copyright (c) 2014-2019 Ultraschall (http://ultraschall.fm)
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# 
################################################################################
]] 

-- written by Meo Mespotine, 1st of December 2019


-- Step 1:
  -- The following code-example let's the FX-button of the TCP jump up, down, left and right
  -- Use the following lines as theme. Just insert the lines into the rtconfig.txt-file, stored in the 
  -- resources-folder/ColorThemes/yourtheme-folder/rtconfig.txt

  --[[
  ; Example-theme for set/get-theme-layout functions in ReaScript/Reaper-API, as supported by Reaper 6
  ; written by Meo Mespotine, 1st of December 2019
  
  ; This is a simple theme, which allows a jumping fx-button
  ; You can influence the x(param1) and y(param2)-position of the fx-button programmatically.
  ; Use the API-functions: ThemeLayout_GetParameter, ThemeLayout_SetParameter, ThemeLayout_RefreshAll and the
  ; parameter wp set to 1(x-position) or 2(y-position)
  
  define_parameter 'defaultV6' 'defaultV6_version' 1 ; needed by Reaper, for the ThemeLayout_functions to work
  
;                   parameterIDX  name(will be shown in API)  Defaultval  MinValue  Maxvalue
define_parameter    param1        "xposition"                 100         0         205       ; defines first parameter, called param1, which is the x-position
define_parameter    param2        "yposition"                 100         0         205       ; defines first parameter, called param2, which is the y-position

;The paramIDX, like param1 and param2 and param298 can be used as "variables" for numbers. 

; In set tcp.fx [param1 param2 20 20 0 0 0 0], the first two numbers will be represented by the values of param1 and param2
; They can be influenced from the API, in this theme it influences x and y-position of the fx-button

  clear tcp.*                                   ; clear tcp, so we can see the jumping fx-button without a problem
  
  set tcp.fx [param1 param2 20 20 0 0 0 0]      ; set the fx-button of the tcp, param1=x-position, param2=y-position
  
  
  --]]


-- Step 2:
  -- Copy the following lines into the ReaperTheme-file of your theme, stored in the
  -- resources-folder/ColorThemes/yourtheme.ReaperTheme
  
  --[[
  
[REAPER]
ui_img=yourtheme

--]]


-- Step 3:
  -- run the following code and see a nice little happy fx-button jump out of joy in the tcp

  x=1     -- x position
  y=1     -- y position
  x_dir=true -- true, move fx-button toward the right; false, move fx-button toward the left
  y_dir=true -- true, move fx-button toward the bottom; false, move fx-button toward the top
  
  function main()
    if x>500  then x_dir=false end -- if fx-button is on the right, go to the left
    if x<0    then x_dir=true end  -- if fx-button is on the left, go to the right
    if y>100  then y_dir=false end -- if fx-button is at the bottom, go to the top
    if y<0    then y_dir=true end  -- if fx-button is at the top, go to the bottom
    
    if x_dir==true then x=x+6 else x=x-6 end                 -- move fx-button's x-position
    if y_dir==true then y=y+3+(y*0.2) else y=y-3-(y*0.2) end -- move fx-button's y-position, 
    y=math.floor(y)                                          --   including some basic gravity ;)
  
    reaper.ThemeLayout_SetParameter(1,x,false) -- set the x-position of the fx-button
    reaper.ThemeLayout_SetParameter(2,y,false) -- set the y-position of the fx-button
    reaper.ThemeLayout_RefreshAll()            -- refresh the theme-layout
    
    reaper.defer(main) -- and repeat over and over again
  end
  
  main()